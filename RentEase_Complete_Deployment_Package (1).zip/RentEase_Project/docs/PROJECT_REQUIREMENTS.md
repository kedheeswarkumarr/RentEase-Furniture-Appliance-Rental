# RentEase — Requirements and Implementation Status

## Project objective
A responsive web application for monthly furniture and appliance rentals, including a customer-facing catalog and an admin workflow.

## Implemented in this starter
- Responsive storefront with product search and category filters.
- Seed catalog with furniture and appliances, monthly rent, deposit, description, image and stock.
- Registration/login with bcrypt password hashes and session authentication.
- Rental request form with 1, 3, 6 or 12 month plans, delivery date and address.
- Customer rental history and rental statuses.
- Support/maintenance request submission and admin status updates.
- Admin overview metrics, product add/hide/edit basic pricing/stock, rental status management and user listing API.
- SQLite database and sample records.
- Health endpoint at `/healthz`; configurable SQLite path for a persistent hosting volume.

## Requirement matrix
| Requirement | Status | Notes |
|---|---|---|
| Responsive web platform | Implemented in source; verify on target devices | Browser testing required |
| Browse Furniture/Appliances | Implemented | Search and category filters |
| Price, deposit, tenure options | Implemented | 1/3/6/12 months |
| Registration and login | Implemented | Needs live end-to-end test |
| Cart and checkout | Partial | Single-item rental request flow; no multi-item cart or payment |
| Delivery date and location | Partial | Date/address captured; no map, postal coverage validation or logistics integration |
| Manage active rentals/history | Partial | History and status; no customer-side extension/return scheduling controls |
| Maintenance requests | Partial | Support requests and admin resolution status |
| Inventory management | Partial | Admin can add/hide and update stock/rent; no image upload |
| Delivery/pickup schedule | Partial | Delivery date and status fields; no calendar view or pickup date field |
| Admin user/order monitoring | Partial | Summary, rentals and users API; no advanced search/export |
| Disputes and damage claims | Missing | Not implemented as a distinct workflow |
| Reports and analytics | Partial | Basic counts and planned rental value only |
| Service area management | Missing | No service-area table or postal-code validation |
| Real payment gateway | Missing | Demo request only; no money collected |
| Multi-city scaling | Not production-ready | Requires deployment/database/session/security review |

## Non-functional considerations
- Passwords are hashed with bcryptjs.
- Production requires environment-provided `SESSION_SECRET` and `ADMIN_PASSWORD`.
- Use HTTPS, persistent storage, backups, rate limiting, CSRF protection, privacy/terms pages and a security review before real customer use.
- The current app uses SQLite and the Express default in-memory session store. The included Render blueprint provides persistent SQLite storage, but the in-memory session store is still intended for a small demo, not a high-availability service.

## Suggested demo script
1. Open the storefront and filter Furniture / Appliances.
2. Register a test customer and sign in.
3. Submit a rental request using a future delivery date and test address.
4. Open My Rentals and confirm the request appears.
5. Submit a support request.
6. Sign in with the admin account and change rental/support statuses; add or hide a product.
7. Refresh and confirm database-backed data remains available.

Use synthetic test information only; do not enter real customer or payment data in a college demo.
